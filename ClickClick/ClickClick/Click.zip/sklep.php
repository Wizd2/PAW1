<?php
// ================================
// ClickClick — sklep.php 
// Ten plik robi kategorie sklepu.
// W chodzi o to, zeby:
// - miec tabele kategorii w bazie danych
// - wyswietlic je w formie drzewa (rekurencja)
//
// Uwaga: polaczenie do bazy jest w cfg.php (zmienna $link)
// ================================

// Dolaczamy helpery (require_once, zeby nie bylo "Cannot redeclare")
require_once __DIR__. '/helpers.php';

// Pobieramy jedna kategorie po ID (przydaje sie jak user kliknie kategorie)
function cc_get_category_by_id(int $id): ?array {
 global $link;

 $id = (int)$id;
 if ($id <= 0) {
 return null;
 }

 $q = mysqli_query($link, "SELECT id, parent_id, name FROM categories WHERE id=$id LIMIT 1");
 if (!$q) {
 return null;
 }

 $row = mysqli_fetch_assoc($q);
 return $row ?: null;
}

// Rekurencyjne wyswietlanie drzewa kategorii
// parent_id = 0 oznacza "kategorie glowne"
function cc_render_category_tree(int $parent_id = 0, int $level = 0): string {
 global $link;

 $parent_id = (int)$parent_id;
 $level = (int)$level;

 // Pobieramy dzieci (podkategorie) dla danego parent_id
 $q = mysqli_query(
 $link,
 "SELECT id, parent_id, name FROM categories WHERE parent_id=$parent_id ORDER BY name ASC"
 );

 if (!$q) {
 // Jak cos poszlo nie tak, to pokazujemy blad (na labach to pomaga)
 return '<div class="card" style="border-color: rgba(239,68,68,.45); background: rgba(239,68,68,.08);">'
. '<b>Błąd SQL:</b> '. cc_h(mysqli_error($link))
. '</div>';
 }

 $items = '';
 while ($row = mysqli_fetch_assoc($q)) {
 $id = (int)$row['id'];
 $name = cc_h($row['name']);

 // Link do wybranej kategorii (cat=ID)
 $items.= '<li style="margin: 6px 0;">'
. '<a href="index.php?idp=kategorie&cat='. $id. '"><b>'. $name. '</b></a>';

 // Rekurencja: probujemy wyrenderowac dzieci
 $childHtml = cc_render_category_tree($id, $level + 1);

 // Zeby nie robic pustych <ul>, sprawdzamy czy w srodku jest jakis <li>
 if (strpos($childHtml, '<li') !== false) {
 $items.= '<ul class="ul" style="margin-top:6px; margin-left: '. (14 + $level * 10). 'px;">'
. $childHtml
. '</ul>';
 }

 $items.= '</li>';
 }

 // Zwracamy same <li> (a <ul> dodamy wyzej, gdzie trzeba)
 return $items;
}

// Glowna funkcja: pokazuje strone "Kategorie"
function PokazKategorieSklepu(): string {
 // Uproszczona strona "Wszystkie kategorie" — tylko 3 główne działy sklepu.
 // Linki prowadzą do stron z produktami (idp=switches/keycaps/cables).
 return '<section class="card" style="margin-top:14px;">'
. '<h2>Wszystkie kategorie</h2>'
. '<p>Wybierz dział i przejdź do produktów.</p>'
. '<div class="categoryGrid">'
.   '<a class="categoryCard" href="index.php?idp=switches">'
.     '<div class="categoryTitle">Switche</div>'
.     '<div class="categoryMeta">Linear / Tactile / Clicky</div>'
.   '</a>'
.   '<a class="categoryCard" href="index.php?idp=keycaps">'
.     '<div class="categoryTitle">Keycapy</div>'
.     '<div class="categoryMeta">PBT / ABS / Artisan</div>'
.   '</a>'
.   '<a class="categoryCard" href="index.php?idp=cables">'
.     '<div class="categoryTitle">Kable</div>'
.     '<div class="categoryMeta">USB-C / Aviator / Coiled</div>'
.   '</a>'
. '</div>'
. '</section>';
}
